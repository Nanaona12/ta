# ghostnet with v8v2 > 2024-07-18 8:25am
https://universe.roboflow.com/geolocation-v8/ghostnet-with-v8v2

Provided by a Roboflow user
License: CC BY 4.0

